package com.pe.sanpedro.mybatis.mapper;

import java.util.List;

import com.pe.sanpedro.model.Especialidad;

public interface EspecialidadMapper {

	public List<Especialidad> listaEspecialidades() throws Exception;

}
