package com.pe.sanpedro.mybatis.mapper;

import java.util.List;
import com.pe.sanpedro.model.HorarioMedico;

public interface HorarioMedicoMapper {
	public List<HorarioMedico> listado()throws Exception;
}

