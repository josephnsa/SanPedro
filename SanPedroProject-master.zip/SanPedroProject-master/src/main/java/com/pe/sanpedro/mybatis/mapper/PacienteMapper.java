package com.pe.sanpedro.mybatis.mapper;

import java.util.HashMap;

public interface PacienteMapper {

	public int registrar(HashMap<Object, Object>params) throws Exception;
	
}
